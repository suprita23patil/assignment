document.addEventListener('DOMContentLoaded', function() {
  var userListElement = document.getElementById('userList');

  // Simulated data or you can fetch data from PHP server using AJAX
  var users = [
    { name: 'John Doe', email: 'john@example.com' },
    { name: 'Jane Smith', email: 'jane@example.com' },
    { name: 'Michael Johnson', email: 'michael@example.com' }
  ];

  // Iterate over the users and create user cards
  users.forEach(function(user) {
    var userCard = document.createElement('div');
    userCard.className = 'card user-card';
    
    var cardBody = document.createElement('div');
    cardBody.className = 'card-body';
    
    var nameElement = document.createElement('h5');
    nameElement.className = 'card-title';
    nameElement.textContent = user.name;
    
    var emailElement = document.createElement('p');
    emailElement.className = 'card-text';
    emailElement.textContent = user.email;
    
    cardBody.appendChild(nameElement);
    cardBody.appendChild(emailElement);
    userCard.appendChild(cardBody);
    
    userListElement.appendChild(userCard);
  });
});
