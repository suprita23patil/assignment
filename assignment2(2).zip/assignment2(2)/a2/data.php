<?php
// Simulated data
$users = [
  ['name' => 'John Doe', 'email' => 'john@example.com'],
  ['name' => 'Jane Smith', 'email' => 'jane@example.com'],
  ['name' => 'Michael Johnson', 'email' => 'michael@example.com']
];

header('Content-Type: application/json');
echo json_encode($users);
?>
